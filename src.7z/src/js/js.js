

var vm = new Vue({
  el: '#app',
  data: {
    msg: 'Hello Vue.js!',
    act_time: 4,
    act_rounds:4,
    act_desc:1,
    act_preaviso: 1,
    act_preaviso_text:["asalto","descanso","asalto y descanso","nada"],
    act_idioma_text:["Español","Catalan","ingles"],
    act_idioma:0,
    act_theme_text:["black","color","white"],
    act_theme:1
},
methods: {
      add: function(variable) {

         if (this[variable+"_text"]){
          if ( this[variable]>this[variable+"_text"].length){
            this[variable]=0;
           return
         }
          
   }
   this[variable]++;
      },
       sub: function(variable) {
         if (this[variable+"_text"]){
        if ( this[variable]==0){
          this[variable]=this[variable+"_text"].length-1;
          console.log( this[variable]);
        return
      }
    }

    this[variable]-=1*( this[variable]>0);
         
      }
    
  
}
})