Vue.filter('time', function(value) {

    let minutes = parseInt(Math.floor((value) / 60));
    let seconds = parseInt((value - ((minutes * 60))) % 60);


    let dMins = (minutes > 9 ? minutes : '0' + minutes);
    let dSecs = (seconds > 9 ? seconds : '0' + seconds);

    return dMins + ":" + dSecs;
});


var vm = new Vue({
    el: '#app',
    created () {    
        window.addEventListener('beforeunload', this.saveall)  ;
         if (localStorage.backup) {
      this.backup = localStorage.backup;
    }
    }, 
    data: {
      a:{
        backup:"",
        act_time: 240,
        act_rounds: 4,
        act_desc: 60,
        act_preaviso: 1,
        act_preaviso_text: ["asalto", "descanso", "asalto y descanso", "nada"],
        act_idioma_text: ["Español", "Catalan", "ingles"],
        act_sonidos_text: ["sirena", "campana", "dong", "buzzer", "slap", "timbre"],
        sonido_asaltos: 1,
        sonido_descanso: 0,
        sonido_preaviso: 2,
        sonido_fin: 3,
        act_idioma: 0,
        act_theme_text: ["black", "color", "white"],
        act_theme: 1,
        sesionName: "nombre",
        rounds: 0,
        segundos: 60,
        minutos: 2,
        running: false,
        sts_panel: 0,
        status: "main",
        fontSize: 5,
        sesiones: [{
                nombre: "combate",
                rounds: 1,
                time: 3,
                desc: 60,
                preaviso: 0
            },
            {
                nombre: "calentamiento",
                rounds: 2,
                time: 2,
                desc: 60,
                preaviso: 0
            },
            {
                nombre: "entrenamiento",
                rounds: 3,
                time: 1,
                desc: 60,
                preaviso: 0
            }
        ],
    }},
   

    methods: {
        saveall: function() {
          this.backup=  JSON.stringify(this);
            console.log("hjhjhjhjhjjhjjhjh");

        },
        pause: function() {
            this.running = false;
            clearInterval(this.crono);
            this.segundos = 60;
        },
        go: function() {

            const myself = this;
            this.running = true;
            this.rounds = this.act_rounds;
            this.minutos = this.act_time;
            asalto();

            function asalto() {
                
                myself.crono = setInterval(
                    function() {
                        myself.minutos--;
                        if (myself.minutos == 0) {
                                    clearInterval(myself.crono);
                                if (myself.rounds > 1) {
                                    myself.rounds--;
                                    myself.minutos = myself.act_desc;
                                    descanso();
                                } else {
                                    myself.status = "fin";
                                }
                        }

                        function descanso() {
                            myself.status = "descanso";
                            myself.descrono = setInterval(
                                function() {
                                    myself.minutos--;
                                    if (myself.minutos < 0) {
                                        clearInterval(myself.descrono);

                                        if (myself.rounds > 0) {
                                            myself.status = "round";
                                            myself.minutos = myself.act_time;
                                            asalto();
                                        } else {
                                            console.log("finito");
                                        }
                                    }

                                }, 50);
                        }
                    }, 50);
            }


        },
        add: function(variable, valor) {
            if (valor == undefined) valor = 1;
            if (this[variable + "_text"]) {
                if (this[variable] > this[variable + "_text"].length) {
                    this[variable] = 0;
                    return
                }
            }
            this[variable] += valor * 1;
        },
        sub: function(variable, valor) {
            if (valor == undefined) valor = 1;
            if (this[variable + "_text"]) {
                if (this[variable] == 0) {
                    this[variable] = this[variable + "_text"].length - 1;
                    return
                }
            }
            this[variable] -= (1 * valor) * (this[variable] > 0);
        },
        setPanel(sesion) {


        },

        setSesion(sesion) {
            this.act_rounds = sesion.rounds;
            this.act_time = sesion.time;
            this.act_desc = sesion.desc;
            this.act_preaviso = sesion.preaviso;

        },
        deleteSesion(sesion) {
            const todoIndex = this.sesiones.indexOf(sesion);
            this.sesiones.splice(todoIndex, 1);
        },
        addSesion() {
            var newitem = {
                nombre: this.sesionName,
                rounds: this.act_rounds,
                time: this.act_time,
                desc: this.act_desc,
                preaviso: this.act_preaviso
            }
            this.sesiones.push(newitem);
            console.log(this.sesiones);
        }
    }
})